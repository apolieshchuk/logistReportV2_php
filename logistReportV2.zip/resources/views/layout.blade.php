<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @yield('head')
    <title>Document</title>
</head>
<body>
@yield('body')
@yield('footer')
</body>
</html>
