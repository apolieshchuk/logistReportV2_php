<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->yieldContent('head'); ?>
    <title>Document</title>
</head>
<body>
<?php echo $__env->yieldContent('body'); ?>
<?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
<?php /**PATH /home/apolieshchuk/Documents/MyProjects/php/logistReportV2/resources/views/layout.blade.php ENDPATH**/ ?>