<?php $__env->startSection('head'); ?>

<title>Go</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="/css/go.css">





<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.css"/>
<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div style="display: flex; justify-content: center">
    <div style="display:flex; flex-direction: column; margin: 10px;">
        
        <div id="route-select-wrapper" style="margin-bottom: 10px;">
            <select id="routeSelect" class="ui search dropdown" onchange="initRatio()">
                <option value="" selected disabled>Оберіть маршрут</option>
                <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($route['id']); ?>"><?php echo e($route['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div style="text-align: center;">
            <select id="managerSelect" class="ui search dropdown" required disabled>
                <option value="" selected disabled >Оберіть менеджера</option>
                <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($manager['id']); ?>"><?php echo e($manager['surname']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select id="cargoSelect" class="ui search dropdown" required disabled>
                <option value="" selected disabled>Оберіть вантаж</option>
                <?php $__currentLoopData = $cargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cargo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cargo['id']); ?>"><?php echo e($cargo['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <button
        onclick="sendReport()"
        style="align-self: center" class="ui blue button" id="goButton2"
    >Відправити</button>
</div>


<hr style="margin-bottom: 20px;">



<table class="ui celled table" style="width: 80%; margin: auto; min-width: 800px">
    <thead>
        <tr>
            <th>#</th>
            <th class="three wide">Перевізник</th>
            <th class="two wide">Авто</th>
            <th class="two wide">Причеп</th>
            <th class="two wide">Водій</th>
            <th class="one wide">Дата</th>
            <th class="two wide" style="min-width: 80px">Ф2</th>
            <th class="two wide" style="min-width: 80px">Ф1</th>
            <th class="one wide" style="min-width: 80px">Тр</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="data-row">
            <td class="data-col" data-label="#"><?php echo e($key + 1); ?></td>
            <td class="data-col" data-label="Перевізник"> <?php echo e($auto->carrier['name']); ?></td>
            <td class="data-col" data-label="Авто"> <?php echo e($auto['auto_num']); ?></td>
            <td class="data-col" data-label="Причіп"> <?php echo e($auto['trail_num']); ?></td>
            <td class="data-col" data-label="Водій"> <?php echo e($auto->driver->surname); ?></td>
            <td data-label="Дата">
                <div class="ui input" >
                    <input class="data-col" style="padding-right: 2px;padding-left: 2px" type="date" value="<?php echo e(Carbon\Carbon::tomorrow()->format('Y-m-d')); ?>">
                </div>
            </td>
            <td data-label="Ф2">
                <div class="ui input" style="padding: 2px" >
                    <input class="data-col data-col-f2" style="padding-right: 5px;padding-left: 5px" type="number" value="0">
                </div>
            </td>
            <td data-label="Ф1">
                <div class="ui input">
                    <input class="data-col data-col-f1" style="padding-right: 5px;padding-left: 5px" type="number" value="0">
                </div>
            </td>
            <td class="data-col data-col-tr"  data-label="Тр">
                <select class="ui search dropdown">
                    <option value="0">НІ</option>
                    <option value="1">ТАК</option>
                </select>
            </td>
            <input type="hidden" class="data-col data-col-carrier-id" value="<?php echo e($auto["carrier_id"]); ?>">
            <input type="hidden" class="data-col" value="<?php echo e($auto["driver_id"]); ?>">
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script src="/js/go.js"></script>










<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.js"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/apolieshchuk/Documents/MyProjects/php/logistReportV2/resources/views/go.blade.php ENDPATH**/ ?>