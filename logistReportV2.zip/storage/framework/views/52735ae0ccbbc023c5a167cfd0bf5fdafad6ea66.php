<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="/css/auto.css">
<link rel="stylesheet" href="https://cdn.datatables.net/select/1.3.1/css/select.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <header>
        <button class="button" id="clearButton">Очистити</button>
        <button class="button" id="copyButton">Копіювати</button>
    </header>
    <table id="autoTable" class="display" style="width:100%;
     table-layout: fixed; display: none">
        <thead>
            <tr>
                <th style="width: 5px"></th>
                <th style="width: 180px">Назва</th>
                <th style="width: 30px">Марка</th>
                <th style="width: 110px">№авт</th>
                <th style="width: 110px">№прич</th>
                <th style="width: 110px">Прiзвище</th>
                <th style="width: 110px">Iмя</th>
                <th style="width: 130px">По-батьк</th>
                <th style="width: 130px">Тел</th>
                <th>Замiтки</th>
            </tr>
            <tr>
                <th style="width: 5px"></th>
                <th style="width: 180px">Назва</th>
                <th style="width: 30px">Марка</th>
                <th style="width: 110px">№авт</th>
                <th style="width: 110px">№прич</th>
                <th style="width: 110px">Прiзвище</th>
                <th style="width: 110px">Iмя</th>
                <th style="width: 130px">По-батьк</th>
                <th style="width: 130px">Тел</th>
                <th>Замiтки</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th style="width: 5px"></th>
                <th style="width: 180px">Назва</th>
                <th style="width: 30px">Марка</th>
                <th style="width: 110px">№авт</th>
                <th style="width: 110px">№прич</th>
                <th style="width: 110px">Прiзвище</th>
                <th style="width: 110px">Iмя</th>
                <th style="width: 130px">По-батьк</th>
                <th style="width: 130px">Тел</th>
                <th>Замiтки</th>
            </tr>
        </tfoot>
        <tbody>
        <?php $__currentLoopData = $autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>


                </td>
                <td><?php echo e($auto['name']); ?></td>
                <td><?php echo e($auto['mark']); ?></td>
                <td><?php echo e($auto['auto_num']); ?></td>
                <td><?php echo e($auto['trail_num']); ?></td>
                <td><?php echo e($auto['dr_surn']); ?></td>
                <td><?php echo e($auto['dr_name']); ?></td>
                <td><?php echo e($auto['dr_fath']); ?></td>
                <td><?php echo e($auto['tel']); ?></td>
                <td><?php echo e($auto['notes']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<script src="/js/auto.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/select/1.3.1/js/dataTables.select.min.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/apolieshchuk/Documents/MyProjects/php/logistReportV2/resources/views/auto.blade.php ENDPATH**/ ?>