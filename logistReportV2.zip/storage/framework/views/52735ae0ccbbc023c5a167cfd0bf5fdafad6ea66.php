<?php $__env->startSection('head'); ?>
<title>Autos</title>


<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="/css/auto.css">
<link rel="stylesheet" href="https://cdn.datatables.net/select/1.3.1/css/select.dataTables.min.css">







<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.css"/>











<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div style="padding: 0 10px; display: flex; flex-direction: column">
    <div
        style="margin-bottom: 10px; width: 750px; align-self: center; margin-top: 10px"
        class="five ui buttons" >
        <button class="ui blue button" onclick="showModal()" id="addAutoButton">
            <i class="plus circle icon"></i> Додати
        </button>
        <button class="ui blue button" id="clearButton">
            <i class="erase icon"></i>Очистити</button>
        <button class="ui blue button" id="copyButton" onclick="copyAutos()">
            <i class="copy outline icon"></i>Копіювати</button>
        <button class="ui blue button" id="goButton">
            <i class="share icon"></i>Відправити</button>
        <button class="ui blue button" onclick="location='/report'" id="reportButton">
            <i class="list icon"></i>Звіт</button>
    </div>
    <nav style="margin-bottom: 10px; text-align: center;"
         class="navbar navbar-default" role="navigation">
        <div style="text-align: center" class="navbar-text ui input">
            <input style="height: 35px" type="text" id="filterbox" placeholder="Пошук">
        </div>
    </nav>
    <hr style="width: 100%; height: 1px">
    <table id="autoTable" class="display cell-border" style="width:100%;">
        <thead>
        <tr>
            <th></th>
            <th>Перевізник</th>
            <th>Марка</th>
            <th>№авт</th>
            <th>№прич</th>
            <th>Прiзвище</th>
            <th>Iмя</th>
            <th>По-батьк</th>
            <th>Тел</th>
            <th>Посвідчення</th>

        </tr>
        <tr id="filter-col">
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>

        </tr>
        </thead>
        <tfoot>
        <tr>
            <th></th>
            <th>Перевізник</th>
            <th>Марка</th>
            <th>№авт</th>
            <th>№прич</th>
            <th>Прiзвище</th>
            <th>Iмя</th>
            <th>По-батьк</th>
            <th>Тел</th>
            <th>Посвідчення</th>

        </tr>
        </tfoot>
    </table>
</div>


<div class="ui modal"
style="padding: 0 20px 20px 20px; width: 500px">
    <i class="close icon"></i>
    <div class="header">
        Додати авто
    </div>
    <form class="ui form" method="POST" action="/">
        <?php echo csrf_field(); ?>
        <h4 class="ui dividing header">Автомобіль</h4>
        <div class="field">
            <label>Перевізник</label>
            <div class="two fields">
                <div class="fourteen wide field">
                    <select name='carrier_id' id="carrierSelect" class="ui search dropdown">
                        <option value="" selected disabled>Перевізник</option>
                        <?php $__currentLoopData = $carriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($carrier['id']); ?>"><?php echo e($carrier['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="two wide field">
                    <i class="plus square icon"
                       style="font-size:36px; color:#2185d0; cursor: pointer"></i>
                </div>
                
            </div>
        </div>
        <div class="field">
            <label>Авто</label>
            <div class="three fields">
                <div class="field">
                    <input type="text" name="mark" placeholder="Марка авто">
                </div>
                <div class="field">
                    <input id="autoNumInput" type="text" name="auto_num" placeholder="Номер авто">
                </div>
                <div class="field">
                    <input id="trailNumInput" type="text" name="train_num" placeholder="Номер причепу">
                </div>
            </div>
        </div>
        <h4 class="ui dividing header">Водій</h4>
        <div class="field">
            <label>ПІБ</label>
            <div class="three fields">
                <div class="field">
                    <input type="text" name="dr_surn" placeholder="Прізвище">
                </div>
                <div class="field">
                    <input type="text" name="dr_name" placeholder="Ім`я">
                </div>
                <div class="field">
                    <input type="text" name="dr_father" placeholder="По-батькові">
                </div>
            </div>
        </div>
        <div class="field">
            <label>Додаткова інформація</label>
            <div class="two fields">
                <div class="field">
                    <input id="licenseInput" type="text" name="license" placeholder="Посвідчення">
                </div>
                <div class="field">
                    <input id="telInput" type="text" name="tel" placeholder="Телефон">
                </div>
            </div>
            <div class="field">
                <input id="notesInput" type="text" name="notes" placeholder="Замітки">
            </div>
        </div>
        <div class="field" style="text-align: center">
            <input type="submit" class="ui blue button" value="Додати авто" style="margin: auto">
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>


<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>


<script src="/js/auto.js"></script>


<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/select/1.3.1/js/dataTables.select.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.9/semantic.min.js"></script>









<script src="https://rawgit.com/RobinHerbots/jquery.inputmask/3.x/dist/jquery.inputmask.bundle.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/apolieshchuk/Documents/MyProjects/php/logistReportV2/resources/views/auto.blade.php ENDPATH**/ ?>